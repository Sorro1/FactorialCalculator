package day1;

public class HelloWorld {
    public static void main(String args[]){
        System.out.println("hello world");
        System.out.println("привет меня зовут Соро");
        System.out.println("мне "+16+" лет");
        System.out.println("практика закочилась");

    }

}