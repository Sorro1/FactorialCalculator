package day1;

public class HomeWork {
    public static void main (String args[]){
        System.out.println("home sweet home");
        System.out.println("hello my frend");
        System.out.println(" моей маме " +36+" лет");
        System.out.println("hi Barbie");
        System.out.println("ка ты?");
        System.out.println("IT world");
        System.out.println("моему брату " +18+" лет");
        System.out.println("я люблю спать одна");
        System.out.println("what are you doing?");
        System.out.println("Love soong");
        System.out.println("на улице " +45+" градусов ");
        System.out.println("i like tasty food");
        System.out.println("я " +6+" августа еду в Алмату");
        System.out.println("i'm sorry that i won't be able to see you");
        System.out.println("прошло " +2+" недели");

        


    }
}
